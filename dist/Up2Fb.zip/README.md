Up2Fb
=====

A simple app that uploads pictures from camera or gallery to facebook

This app has the ability to upload a picture taken from your camera or your device's gallery and upload it to your facebook wall.
The facebook default webapp doesn't allow this kind of behavior
